import HomePage from "@/src/components/home/homePage"

export default function Home() {
  return <HomePage />
}


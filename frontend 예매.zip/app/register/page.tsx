import RegisterPage from "@/src/components/register/registerPage"

export default function Page() {
  return <RegisterPage />
}


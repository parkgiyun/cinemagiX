import LoginPage from "@/src/components/login/loginPage"

export default function Page() {
  return <LoginPage />
}


import DashboardPage from "@/src/components/dashboard/dashboardPage"

export default function Page() {
  return <DashboardPage />
}

